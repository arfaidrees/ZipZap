// import 'package:flutter/material.dart';
// import 'package:google_maps_flutter/google_maps_flutter.dart';
// class pickup extends StatefulWidget {
//   @override
//   PICKUP createState() => PICKUP();
// }class PICKUP extends State<pickup> {
//   late GoogleMapController mapController;
//   final TextEditingController _textFieldController = TextEditingController();
//   void _showMap(String location) {
//     // Use the location data to display the map
//     print('Showing map for location: $location');
//     // You can customize the map according to the location if needed
//   }@override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       // appBar: AppBar(
//       //   title: Text(''),
//       // ),
//       body: Padding(
//         padding: EdgeInsets.all(16.0),
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: <Widget>[
//             TextField(
//               controller: _textFieldController,
//               decoration: InputDecoration(
//                 labelText: 'Enter a location',
//               ),
//             ),
//             SizedBox(height: 20),
//             ElevatedButton(
//               onPressed: () {
//                 String location = _textFieldController.text;
//                 _showMap(location);
//               },
//               child: Text('Show Map'),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
